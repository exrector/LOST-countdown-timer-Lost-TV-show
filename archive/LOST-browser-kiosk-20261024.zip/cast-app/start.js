'use strict';
// Единственный процесс станции: launchd наблюдает ядро, ядро восстанавливает окна.
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const { spawn, execFile } = require('child_process');
const { promisify } = require('util');
const run = promisify(execFile);
const { start, events } = require('./server');
const { RecoveryController } = require('./runtime');
const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const ROOT = path.resolve(__dirname, '..');
const QUIET = ['--kiosk', '--no-first-run', '--no-default-browser-check', '--disable-notifications', '--noerrdialogs',
    '--disable-session-crashed-bubble', '--hide-crash-restore-bubble', '--disable-features=Translate,TranslateUI,CalculateNativeWinOcclusion'];
const recovery = new RecoveryController();
const windows = { tv: null, console: null };
const peers = { tv: 0, console: 0 };
const heartbeat = { tv: 0, console: 0 };
const modules = { timer: { status: 'starting' }, terminal: { status: 'starting' }, display: { status: 'starting' }, ups: { status: 'starting' } };
let stopping = false, core, caffeinate, castSession, screens = [], lastScreensAt = 0, lastUPSAt = 0, lastUPSStart = 0, busy = false;
const localTimer = ['local', 'both'].includes(cfg.output || 'chromecast');
function profile(role) { return path.join(os.tmpdir(), role === 'tv' ? 'lost-timer-profile' : 'lost-terminal-profile'); }
function getJSON(port, route, timeout = 3000, headers = {}) {
    return new Promise((resolve, reject) => {
        const req = http.get({ host: '127.0.0.1', port, path: route, headers }, res => {
            let body = ''; res.on('data', c => { body += c; if (body.length > 262144) req.destroy(new Error('response too large')); });
            res.on('end', () => { if (res.statusCode !== 200) return reject(new Error('HTTP ' + res.statusCode)); try { resolve(JSON.parse(body)); } catch (_) { reject(new Error('invalid JSON')); } });
        });
        req.setTimeout(timeout, () => req.destroy(new Error('timeout'))); req.on('error', reject);
    });
}
async function readScreens() {
    const script = 'ObjC.import("AppKit"); const s=$.NSScreen.screens,r=[];for(let i=0;i<s.count;i++){const sc=s.objectAtIndex(i),f=sc.frame;r.push({name:ObjC.unwrap(sc.localizedName),x:f.origin.x,y:f.origin.y,w:f.size.width,h:f.size.height});}JSON.stringify(r)';
    try {
        const { stdout } = await run('/usr/bin/osascript', ['-l','JavaScript','-e',script], { timeout: 4000 });
        const list = JSON.parse(stdout), H0 = list[0]?.h || 0;
        return list.map(d => ({ ...d, x: Math.round(d.x), y: Math.round(H0 - d.y - d.h), w: Math.round(d.w), h: Math.round(d.h) }));
    } catch (_) { console.error('[экран] временно не удалось прочитать список экранов'); return null; }
}
function timerDisplay() { return screens.find(d => d.name === cfg.display) || (screens.length > 1 ? screens[screens.length - 1] : null); }
async function closeWindow(role) {
    const child = windows[role]; windows[role] = null;
    if (child?.pid) try { process.kill(-child.pid, 'SIGTERM'); } catch (_) {}
    // Удаляет также осиротевший Chrome после аварии предыдущего ядра. Только профиль LOST.
    try { await run('/usr/bin/pkill', ['-f', role === 'tv' ? 'lost-timer-profile' : 'lost-terminal-profile'], { timeout: 3000 }); } catch (_) {}
}
async function openWindow(role) {
    if (stopping || !fs.existsSync(CHROME)) return false;
    const display = role === 'tv' ? timerDisplay() : screens[0];
    if (!display) return false;
    await closeWindow(role);
    if (stopping) return false;
    fs.rmSync(profile(role), { recursive: true, force: true });
    const url = 'http://localhost:' + core.port + (role === 'tv' ? '/index.html?mode=' + core.getMode() : '/console.html');
    const args = ['--app=' + url, '--window-position=' + display.x + ',' + display.y, '--window-size=' + display.w + ',' + display.h,
        ...QUIET, '--user-data-dir=' + profile(role), '--autoplay-policy=no-user-gesture-required', '--disable-renderer-backgrounding',
        '--disable-background-timer-throttling', '--disable-backgrounding-occluded-windows'];
    if (role === 'tv') args.push('--force-device-scale-factor=1');
    const child = spawn(CHROME, args, { stdio: 'ignore', detached: true }); windows[role] = child;
    child.on('error', error => { console.error('[окно]', role, error.code || 'launch failed'); if (windows[role] === child) windows[role] = null; });
    child.on('exit', () => { if (windows[role] === child) windows[role] = null; });
    child.unref();
    console.log('[окно]', role, 'запуск на', display.name);
    return true;
}
async function ensureUPS() {
    if (Date.now() - lastUPSStart < 60000) return;
    lastUPSStart = Date.now();
    const plist = path.join(os.homedir(), 'Library/LaunchAgents/com.exrector.lost-ups.plist');
    if (!fs.existsSync(plist)) return;
    const domain = 'gui/' + process.getuid();
    try { await run('/bin/launchctl', ['kickstart', domain + '/com.exrector.lost-ups'], { timeout: 4000 }); }
    catch (_) { try { await run('/bin/launchctl', ['bootstrap', domain, plist], { timeout: 4000 }); } catch (_) {} }
}
async function pollUPS() {
    try {
        const state = await getJSON(8766, '/state', 3000, { Origin: 'http://localhost:' + core.port });
        const fresh = state.online && Date.now() - state.updatedAt < 20000;
        modules.ups = { status: fresh ? 'ready' : 'degraded', updatedAt: state.updatedAt || null, error: fresh ? null : 'Нет актуальных показаний ИБП' };
    } catch (_) { modules.ups = { status: 'unavailable', error: 'Агент энергоконтура недоступен' }; await ensureUPS(); }
}
async function tick() {
    if (stopping || busy) return; busy = true;
    try {
        const now = Date.now();
        if (now - lastScreensAt > 10000) {
            lastScreensAt = now; const next = await readScreens(); if (next) screens = next;
        }
        const display = timerDisplay();
        modules.display = { status: display ? 'ready' : 'waiting', name: display?.name || cfg.display || null };
        if (localTimer && !display && windows.tv) await closeWindow('tv');
        for (const role of ['console', ...(localTimer ? ['tv'] : [])]) {
            const available = role === 'tv' ? !!display : !!screens[0];
            recovery.observe(role, { connected: peers[role] > 0, lastHeartbeat: heartbeat[role] || undefined, processAlive: !!windows[role], available });
            const healthy = peers[role] > 0 && (!heartbeat[role] || now - heartbeat[role] < 45000);
            modules[role === 'tv' ? 'timer' : 'terminal'] = { status: healthy ? 'ready' : available ? 'recovering' : 'waiting', connections: peers[role], heartbeatAge: heartbeat[role] ? Math.floor((now - heartbeat[role]) / 1000) : null };
            if (recovery.beginAttempt(role)) {
                let launched = false;
                try { launched = await openWindow(role); } finally { recovery.completeAttempt(role, { launched }); }
            }
        }
        if (now - lastUPSAt > 5000) { lastUPSAt = now; await pollUPS(); }
    } catch (error) { console.error('[надзор]', error.code || error.message); }
    finally { busy = false; }
}
async function shutdown(code = 0) {
    if (stopping) return; stopping = true; recovery.stop();
    console.log('[ядро]', code === 0 ? 'штатный выход' : 'аварийное завершение');
    try { core?.saveState(); } catch (_) {}
    try { castSession?.close(); } catch (_) {}
    for (const role of ['console','tv']) await closeWindow(role);
    try { caffeinate?.kill(); } catch (_) {}
    // Значок закрывается вместе со станцией; обработчик quit безопасен при уже остановленном ядре.
    try { await run('/usr/bin/osascript', ['-e', 'if application "LOST" is running then tell application "LOST" to quit'], { timeout: 4000 }); } catch (_) {}
    process.exit(code);
}
process.on('SIGINT', () => shutdown(0)); process.on('SIGTERM', () => shutdown(0)); process.on('SIGHUP', () => shutdown(0));
process.on('uncaughtException', error => { console.error('[ядро] uncaught exception:', error.message); shutdown(1); });
process.on('unhandledRejection', error => { console.error('[ядро] unhandled rejection:', error?.message || 'error'); shutdown(1); });
events.on('quit', () => shutdown(0));
events.on('peers', counts => { peers.tv = counts.tv; peers.console = counts.console; });
events.on('client-alive', beat => { if (beat.role in heartbeat) heartbeat[beat.role] = Date.now(); });
(async () => {
    core = await start(cfg.port, { audioDefault: 'speakers', stage: cfg.stage, display: cfg.display, sleepFrom: cfg.sleepFrom, getRuntimeStatus: () => modules });
    caffeinate = spawn('/usr/bin/caffeinate', ['-d','-i','-w',String(process.pid)], { stdio: 'ignore' }); caffeinate.on('error', () => {}); caffeinate.unref();
    screens = await readScreens() || []; lastScreensAt = Date.now();
    await openWindow('console'); if (localTimer) await openWindow('tv');
    if (['chromecast','both'].includes(cfg.output || 'chromecast')) {
        try { castSession = await require('./cast').castSite(cfg.chromecast, 'http://' + core.ip + ':' + core.port + '/index.html?mode=' + core.getMode()); }
        catch (_) { console.error('[cast] подключение недоступно'); }
    }
    await tick(); setInterval(tick, 2000);
    if (process.env.LOST_SUPERVISED === '1') {
        run('/usr/bin/open', [path.join(ROOT, 'LOST.app')], { timeout: 5000 }).catch(() => {});
    }
    console.log('[ядро] станция запущена; режим:', core.getMode(), '; выход — через меню LOST');
})().catch(error => { if (error.code === 'EADDRINUSE') { console.log('[ядро] LOST уже запущен'); process.exit(0); } else { console.error('[ядро] запуск:', error.code || error.message); shutdown(1); } });
