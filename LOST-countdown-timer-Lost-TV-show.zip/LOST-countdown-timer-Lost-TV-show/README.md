# lost-timer

I coded the LOST countdown timer with JavaScript, jQuery, HTML, and CSS. Every 108 minutes the code must be entered into the terminal. Failure to enter the number will resulit in catastrophic failure. The number can only be entered wht there are 4 minutes left. If the timer reaches zero, the timer numbers get replaced by red and black Egyptian hieroglyphics and a voice saying "system failure" plays over and over again. So, enter the numbers, and save the world.

4 8 15 16 23 42